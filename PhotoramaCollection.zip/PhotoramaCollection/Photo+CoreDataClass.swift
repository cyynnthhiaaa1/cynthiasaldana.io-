//
//  Photo+CoreDataClass.swift
//  Photorama
//
//  Created by Cynthia  Saldana  on 5/4/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//
//

import Foundation
import CoreData

@objc(Photo)
public class Photo: NSManagedObject {

}
