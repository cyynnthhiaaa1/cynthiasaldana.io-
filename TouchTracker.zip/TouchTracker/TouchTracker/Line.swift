//
//  Line.swift
//  TouchTracker
//
//  Created by Cynthia  Saldana  on 4/11/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import Foundation
import CoreGraphics


struct Line{
    
    var begin = CGPoint.zero
    var end = CGPoint.zero
    
}
