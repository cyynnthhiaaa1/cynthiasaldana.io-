//
//  ViewController.swift
//  PayYourBills
//
//  Created by Cynthia  Saldana  on 3/16/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
   
   

    
    @IBOutlet weak var Calendar: UICollectionView!
    
    @IBOutlet weak var MonthLabel: UILabel!
    
    

    let Months =
        ["January","February","March","April","May","June","July","August","September","October","November","December"]
    let DayOfMonth = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    
    var DaysInMonths = [31,28,31,30,31,30,31,31,30,31,30,31]
    
    var currentMonth = String()
    var NumberOfEmptyBoxes = Int()
    var NextNumberEmptyBoxes = Int()
    var PrevNumberOfEmptyBox = 0
    var Direction = 0
    var PositionIndex = 0
    var LeapYearNum = 2
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        currentMonth = Months[month]
        
        MonthLabel.text = "\(currentMonth) \(year)"
        
    }
    
    
    
    
    
    @IBAction func Next(_ sender: Any) {
        switch currentMonth {
        case "December":
            month = 0
            year += 1
            Direction = 1
            
            if LeapYearNum < 5 {
                LeapYearNum += 1
            }
            if LeapYearNum == 4 {
                DaysInMonths[1] = 29
            }
            if LeapYearNum == 5 {
                LeapYearNum = 1
                DaysInMonths[1] = 28
            }
            
            GetStartDateDayPosition()
            currentMonth = Months[month]
            
            MonthLabel.text = "\(currentMonth) \(year)"
            Calendar.reloadData()
        default:
            
             Direction = 1
             GetStartDateDayPosition()
              month += 1
             currentMonth = Months[month]
            MonthLabel.text = "\(currentMonth) \(year)"
             Calendar.reloadData()
        }
    }
    
    
    @IBAction func Back(_ sender: Any) {
        switch currentMonth {
        case "January":
            month = 11
            year -= 1
            Direction = 1
            
            
            if LeapYearNum > 0 {
                LeapYearNum -= 1
            }
            if LeapYearNum == 0 {
                DaysInMonths[1] = 29
                LeapYearNum = 4
            }
            else {
                DaysInMonths[1] = 28
            }
            
            
            GetStartDateDayPosition()
            currentMonth = Months[month]
            
            MonthLabel.text = "\(currentMonth) \(year)"
            Calendar.reloadData()
            
        default:
            month -= 1
            Direction = 1
            GetStartDateDayPosition()
            currentMonth = Months[month]
            
            MonthLabel.text = "\(currentMonth) \(year)"
            Calendar.reloadData()
        }
    }
   
    func GetStartDateDayPosition(){
        switch Direction {
        case 0:
        switch day {
        case 1...7:
            NumberOfEmptyBoxes = weekday-day
        case 8...14:
            NumberOfEmptyBoxes = weekday-day - 7
        case 15...21:
            NumberOfEmptyBoxes = weekday-day - 14
        case 22...28:
            NumberOfEmptyBoxes = weekday-day - 21
        case 29...31:
            NumberOfEmptyBoxes = weekday-day - 28
            
        default:
            break
        }
        PositionIndex = NumberOfEmptyBoxes
        
        case 1...:
        NextNumberEmptyBoxes = (PositionIndex + DaysInMonths[month])%7
        PositionIndex = NextNumberEmptyBoxes
        
        case -1:
        PrevNumberOfEmptyBox = (7 - (DaysInMonths[month] - PositionIndex)%7)
        if PrevNumberOfEmptyBox == 7 {
            PrevNumberOfEmptyBox = 0
        }
        PositionIndex = PrevNumberOfEmptyBox
        default:
        fatalError()
    }
}

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch Direction{
        case 0:
        return DaysInMonths[month] + NumberOfEmptyBoxes
        case 1...:
        return DaysInMonths[month] + NextNumberEmptyBoxes
        case -1:
        return DaysInMonths[month] + PrevNumberOfEmptyBox
        default:
        fatalError()
            }
        }
    
       
       func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Calendar", for: indexPath)as! DateCollectionViewCell
        cell.backgroundColor = UIColor.clear
        
        cell.DateLabel.textColor = UIColor.black
        
        if cell.isHidden{
            cell.isHidden = false
        }
        
        
        switch Direction{
        case 0:
            cell.DateLabel.text = "\(indexPath.row + 1 - NumberOfEmptyBoxes)"
        case 1:
            cell.DateLabel.text = "\(indexPath.row + 1 - NextNumberEmptyBoxes)"
        case -1:
            cell.DateLabel.text = "\(indexPath.row + 1 - PrevNumberOfEmptyBox)"
            
        default:
            fatalError()
        }
        if Int(cell.DateLabel.text!)! < 1{
            cell.isHidden = true
        }
        
        switch indexPath.row{
        case 5,6,12,13,19,20,26,27,33,34:
            if Int(cell.DateLabel.text!)! > 0{
                cell.DateLabel.textColor = UIColor.lightGray
            }
        default:
            break
        }
        if currentMonth == Months[calendar.component(.month, from: date) - 1] && year == calendar.component(.year, from: date) && indexPath.row + 1 == day{
            cell.backgroundColor = UIColor.red
        }
            return cell
       
    }

}
