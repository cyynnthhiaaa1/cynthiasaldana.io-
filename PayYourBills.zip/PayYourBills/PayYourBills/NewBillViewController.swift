//
//  NewBillViewController.swift
//  PayYourBills
//
//  Created by Cynthia  Saldana  on 3/29/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//


import UIKit
class NewBillViewController: UIViewController{
   
    
    @IBAction func BackToList(_ sender: Any) {
         self.performSegue(withIdentifier: "BackToList", sender: self)
    }
    
    var nameText = ""
  //  var due = ""
    @IBOutlet weak var BillName: UITextField!
    
    @IBOutlet weak var MinPayment: UITextField!
    
    private var datePicker: UIDatePicker?

    @IBOutlet weak var DatePicker: UITextField!
    
    
    @IBAction func Save(_ sender: Any) {
        self.nameText  = BillName.text!
        performSegue(withIdentifier: "DisplayBill", sender: self)
      //  UserDefaults.standard.set(BillName.text, forKey: "BillName")
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! ListViewController
        vc.finalName = self.nameText
        let vv = segue.destination as! ListViewController
               vv.DueDate = self.nameText
      
       
    }
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        
        datePicker?.addTarget(self, action:
            #selector(NewBillViewController.dateChanged(datePicker:)), for: .valueChanged)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(NewBillViewController.viewTapped(gestureRecognizer:)))
        
        view.addGestureRecognizer(tapGesture)
        DatePicker.inputView = datePicker
        
    }
    @objc func viewTapped(gestureRecognizer: UITapGestureRecognizer){
        
        view.endEditing(true)
    }
    
   @objc func dateChanged(datePicker: UIDatePicker){
    
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat="MM/dd/yyyy"
    
    DatePicker.text = dateFormatter.string(from:datePicker.date)
    view.endEditing(true)
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
   // override func viewDidAppear(_ animated: Bool) {
     //   if let x = UserDefaults.standard.object(forKey: "BillName")as? String{
       //     BillName.text = x
            
        //}
    //}
}
