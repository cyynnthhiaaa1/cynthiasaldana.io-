//
//  ListViewController.swift
//  PayYourBills
//
//  Created by Cynthia  Saldana  on 3/29/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import SwiftUI





class ListViewController: UIViewController{
    var finalName = ""
    var DueDate = " "
    
    @IBAction func AddNewBill(_ sender: Any) {
        self.performSegue(withIdentifier: "AddBillSegue", sender: self)
        
    }
    
    @IBOutlet weak var DisplayBill: UILabel!
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
        DisplayBill.text = "You Owe Money To: " + finalName
      
        UserDefaults.standard.set(DisplayBill.text, forKey: "BillName")
       
    
}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
}
}
