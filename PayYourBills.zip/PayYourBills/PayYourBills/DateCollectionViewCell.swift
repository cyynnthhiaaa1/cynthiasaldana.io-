//
//  DateCollectionViewCell.swift
//  PayYourBills
//
//  Created by Cynthia  Saldana  on 3/27/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var DateLabel: UILabel!
    
    
    
}
