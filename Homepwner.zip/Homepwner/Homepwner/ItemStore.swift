//
//  ItemStore.swift
//  Homepwner
//
//  Created by Cynthia  Saldana  on 4/5/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import Foundation

class ItemStore {
    var allItems = [Item]()
    let itemArchiveURL: URL = {
        let documentsDirectories =
            FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentDirectory = documentsDirectories.first!
        return documentDirectory.appendingPathComponent("items.archive")
        
    }()
  init() {
        if let data = try? Data(contentsOf: itemArchiveURL) {
            if let archivedData = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? [Item] {
                allItems = archivedData ?? [Item]()
            }
        }
    }
    
    
    func moveItem(from fromIndex: Int, to toIndex: Int ){
        if fromIndex == toIndex{
            return
        }
        let movedItem = allItems[fromIndex]
        
        allItems.remove(at: fromIndex)
        allItems.insert(movedItem, at: toIndex)
    }
    
    
    @discardableResult func createItem() -> Item{
    let newItem = Item(random: true )
    
    allItems.append(newItem)
    return newItem
    
    }
    
    func removeItem(_ item: Item){
           if let index = allItems.firstIndex(of: item){
               allItems.remove(at:index)
               
           }
       }
    
       
    func saveChanges() -> Bool {
        print("Saving items to: \(itemArchiveURL.path)")
        return NSKeyedArchiver.archiveRootObject(allItems, toFile: itemArchiveURL.path)
    }

}
