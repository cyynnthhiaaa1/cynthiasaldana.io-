//
//  buttonStore.swift
//  Crossword
//
//  Created by Cynthia  Saldana  on 5/16/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import SwiftUI

class buttonStore{
    var addButton: String = ""
    
   


    class levelStore{
        
        }
    
    
    
}
