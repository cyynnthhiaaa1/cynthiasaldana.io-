//
//  ViewController.swift
//  Crossword
//
//  Created by Cynthia  Saldana  on 4/20/20.
//  Copyright © 2020 Cynthia  Saldana . All rights reserved.
//

import SwiftUI

class ViewController: UIViewController {
     var Char = 0
    let A1:  char = ""
    
    var buttonStore: buttonStore!
    var addButton: String="" 
    
    @IBAction func backgroundTapped(_ sender: Any){
        view.endEditing(true)
    }
    
    func addAllButtons(){
        buttonStore.addButton(A1)
        buttonStore.addButton(A2)
        buttonStore.addButton(A3)
        buttonStore.addButton(A4)
        buttonStore.addButton(A5)
        buttonStore.addButton(A6)
        buttonStore.addButton(A7)
        buttonStore.addButton(A8)
        buttonStore.addButton(A9)
        buttonStore.addButton(A10)
        buttonStore.addButton(A11)
        buttonStore.addButton(A12)
        buttonStore.addButton(A13)
        buttonStore.addButton(B1)
        buttonStore.addButton(B2)
        buttonStore.addButton(B3)
        buttonStore.addButton(B4)
        buttonStore.addButton(B5)
        buttonStore.addButton(B6)
        buttonStore.addButton(B7)
        buttonStore.addButton(B8)
        buttonStore.addButton(B9)
        buttonStore.addButton(B10)
        buttonStore.addButton(B11)
        buttonStore.addButton(B12)
        buttonStore.addButton(B13)
        buttonStore.addButton(C1)
        buttonStore.addButton(C2)
        buttonStore.addButton(C3)
        buttonStore.addButton(C4)
        buttonStore.addButton(C5)
        buttonStore.addButton(C6)
        buttonStore.addButton(C7)
        buttonStore.addButton(C8)
        buttonStore.addButton(C9)
        buttonStore.addButton(C10)
        buttonStore.addButton(C11)
        buttonStore.addButton(C12)
        buttonStore.addButton(C13)
        buttonStore.addButton(D1)
        buttonStore.addButton(D2)
        buttonStore.addButton(D3)
        buttonStore.addButton(D4)
        buttonStore.addButton(D5)
        buttonStore.addButton(D6)
        buttonStore.addButton(D7)
        buttonStore.addButton(D8)
        buttonStore.addButton(D9)
        buttonStore.addButton(D10)
        buttonStore.addButton(D11)
        buttonStore.addButton(D12)
        buttonStore.addButton(D13)
        buttonStore.addButton(E1)
        buttonStore.addButton(E2)
        buttonStore.addButton(E3)
        buttonStore.addButton(E4)
        buttonStore.addButton(E5)
        buttonStore.addButton(E6)
        buttonStore.addButton(E7)
        buttonStore.addButton(E8)
        buttonStore.addButton(E9)
        buttonStore.addButton(E10)
        buttonStore.addButton(E11)
        buttonStore.addButton(E12)
        buttonStore.addButton(E13)
        buttonStore.addButton(F1)
        buttonStore.addButton(F2)
        buttonStore.addButton(F3)
        buttonStore.addButton(F4)
        buttonStore.addButton(F5)
        buttonStore.addButton(F6)
        buttonStore.addButton(F7)
        buttonStore.addButton(F8)
        buttonStore.addButton(F9)
        buttonStore.addButton(F10)
        buttonStore.addButton(F11)
        buttonStore.addButton(F12)
        buttonStore.addButton(F13)
        buttonStore.addButton(G1)
        buttonStore.addButton(G2)
        buttonStore.addButton(G3)
        buttonStore.addButton(G4)
        buttonStore.addButton(G5)
        buttonStore.addButton(G6)
        buttonStore.addButton(G7)
        buttonStore.addButton(G8)
        buttonStore.addButton(G9)
        buttonStore.addButton(G10)
        buttonStore.addButton(G11)
        buttonStore.addButton(G12)
        buttonStore.addButton(G13)
        buttonStore.addButton(H1)
        buttonStore.addButton(H2)
        buttonStore.addButton(H3)
        buttonStore.addButton(H4)
        buttonStore.addButton(H5)
        buttonStore.addButton(H6)
        buttonStore.addButton(H7)
        buttonStore.addButton(H8)
        buttonStore.addButton(H9)
        buttonStore.addButton(H10)
        buttonStore.addButton(H11)
        buttonStore.addButton(H12)
        buttonStore.addButton(H13)
        buttonStore.addButton(I1)
        buttonStore.addButton(I2)
        buttonStore.addButton(I3)
        buttonStore.addButton(I4)
        buttonStore.addButton(I5)
        buttonStore.addButton(I6)
        buttonStore.addButton(I7)
        buttonStore.addButton(I8)
        buttonStore.addButton(I9)
        buttonStore.addButton(I10)
        buttonStore.addButton(I11)
        buttonStore.addButton(I12)
        buttonStore.addButton(I13)
        buttonStore.addButton(J1)
        buttonStore.addButton(J2)
        buttonStore.addButton(J3)
        buttonStore.addButton(J4)
        buttonStore.addButton(J5)
        buttonStore.addButton(J6)
        buttonStore.addButton(J7)
        buttonStore.addButton(J8)
        buttonStore.addButton(J9)
        buttonStore.addButton(J10)
        buttonStore.addButton(J11)
        buttonStore.addButton(J12)
        buttonStore.addButton(J13)
        buttonStore.addButton(K1)
        buttonStore.addButton(K2)
        buttonStore.addButton(K3)
        buttonStore.addButton(K4)
        buttonStore.addButton(K5)
        buttonStore.addButton(K6)
        buttonStore.addButton(K7)
        buttonStore.addButton(K8)
        buttonStore.addButton(K9)
        buttonStore.addButton(K10)
        buttonStore.addButton(K11)
        buttonStore.addButton(K12)
        buttonStore.addButton(K13)
        buttonStore.addButton(L1)
        buttonStore.addButton(L2)
        buttonStore.addButton(L3)
        buttonStore.addButton(L4)
        buttonStore.addButton(L5)
        buttonStore.addButton(L6)
        buttonStore.addButton(L7)
        buttonStore.addButton(L8)
        buttonStore.addButton(L9)
        buttonStore.addButton(L10)
        buttonStore.addButton(L11)
        buttonStore.addButton(L12)
        buttonStore.addButton(L13)
        buttonStore.addButton(M1)
        buttonStore.addButton(M2)
        buttonStore.addButton(M3)
        buttonStore.addButton(M4)
        buttonStore.addButton(M5)
        buttonStore.addButton(M6)
        buttonStore.addButton(M7)
        buttonStore.addButton(M8)
        buttonStore.addButton(M9)
        buttonStore.addButton(M10)
        buttonStore.addButton(M11)
        buttonStore.addButton(M12)
        buttonStore.addButton(M13)
    }
    @IBAction func verticalPressed(_ sender: Any){
        isHorizontal = false
        horizontalButton.isEnabled = true
        vericalButton.isEnabled = false
        
        horizontalButton.backgroundColor = UIColor.lightGray
        verticalButton.backgroundColor = UIColor.yellow
        
        if let button = currentButton{
            let identifier: String = button.accessibilityIdentifier ?? ""
            buttonStore.removeHighlights()
            button.textField.becomeFirstResponder()
            buttonStore.removeHighlights()
            buttonStore.highlightRowColumn(identifier: identifier, isHorizontal)
            updateHint(currentButton: currentButton, isHorizontal: isHorizontal)
        }
    }
    
    func textFieldShouldBeginEditing(_ textField:UITextField) -> Bool{
        if let button = textField.superview as ? CustomButton{
            let identifier: String = button. accessibilityIdentifier ?? ""
            buttonStore.removeHighlights()
            buttonStore.highlightRowColumn(identifier: identifier, isHorizontal)
            
            currentButton = button
            
            updateHInt(currentButton: currentButton, isHorizontal: isHorizontal)
        }
        return true
    }
    func updateHint(currentButtonL CustomButton, isHorizontal: Bool){
        let parentButton = buttonStore.findButtonWithNumber(currentButton: currentButton, isHorizontal: isHorizontal)
        
        if parentButton.number ==0{
            hintLabel.text = "Hint"
        }else{
            if isHorizontal{
                let hint = levelStore.levelOneHorizontalHint[parentButton.number]
                hintLabel.text=hint
            }else{
                let hint = levelStore.levelOneVericalHint[parentButton.number]
                hintLabel.text = hint
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addAllButtons()
        loadButtonAction()
        setupTextFieldDelegate()
        buttonStore.clearTitleText()
        assignbackground()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow),name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHIde),name: UIResponder.keyboardWillShowNotification, object: nil)
        
        horizontalButton.background = UIColor.yellow
        hintLabel.backgroundColor = UIColor(red: 104/255, green: 118/255, blue: 129/255, alpha:0.7)
        
        titleLabel.backgroundColor = UIColor(red: 104/255, green:118/255, blue: 129/255, alpha: 0.7)
        
        buttonStore.loadLevel(levelStore.levelOneString())
        buttonStore.loadCornerNumber(levelStore.numberPosition)
        
    }


}

